package com.example.hariomloginregister;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class s_hw_retrieve extends AppCompatActivity {

    TextView tvHmw;
//    Button retBtn, tmpBtn;
//    DatabaseReference reff;
//
//
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_s_hw_retrieve);
//
//        Intent myIntent = getIntent(); // gets the previously created intent
//        final String firstKeyName = myIntent.getStringExtra("name"); // will return "FirstKeyValue"
//        final String secondKeyName= myIntent.getStringExtra("class"); // will return "SecondKeyValue"
//
//
//
//        Toast.makeText(this, "name:+class:"+firstKeyName+secondKeyName , Toast.LENGTH_SHORT).show();
//
//        tvHmw=(TextView)findViewById(R.id.tvHmw);
//        retBtn=(Button)findViewById(R.id.retBtn);
//
//        tmpBtn=(Button)findViewById(R.id.tmpBtn);
//
//
//        tmpBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(s_hw_retrieve.this, "name:+class:"+firstKeyName+secondKeyName , Toast.LENGTH_SHORT).show();
//                tvHmw.setText(" ");
//            }
//        });
//
//        retBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                reff= FirebaseDatabase.getInstance().getReference().child("HomeworkPost").child("homeWork");      //main line
//                reff.addValueEventListener(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//
//                        String dataa=dataSnapshot.child("name").getValue().toString();        // id under which data is saved on db
//                        tvHmw.setText(""+dataa);                    }
//
//                    @Override
//                    public void onCancelled(@NonNull DatabaseError databaseError) {
//                        Toast.makeText(s_hw_retrieve.this, "Are bhaiya, e ka kar diyo?", Toast.LENGTH_SHORT).show();
//
//                    }
//                });
//            }
//        });
//
//
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s_hw_retrieve);

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        final FirebaseAuth mAuth = FirebaseAuth.getInstance();
        String uid = FirebaseAuth.getInstance().getUid();

        tvHmw=(TextView)findViewById(R.id.tvHmw);

        String userId = mAuth.getCurrentUser().getUid();

        DocumentReference docRef = db.collection("abccc").document("hwPost");
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {


                        System.out.println(document.getData().toString());

                        Map<String, Object> user = new HashMap<>();

                        user=   document.getData();

                        String name= (String) user.get("hw");


                        tvHmw.setText(name);



                    } else {
                        System.out.println("No such ");
                    }
                } else {
                    System.out.println("we are fucked ");
                }
            }
        });
    }
}

