package com.example.hariomloginregister;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class testlogin extends AppCompatActivity  {

    EditText remail,rpswd;
    Button rSignIn;
    TextView tvSingnUp;
    FirebaseAuth mFirebaseAuth;

    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_t_login);

        progressDialog= new ProgressDialog(this);
        mFirebaseAuth=FirebaseAuth.getInstance();
        remail=findViewById(R.id.tfemail);
        rpswd=findViewById(R.id.tfpswd);
        rSignIn=findViewById(R.id.retBtn);
        tvSingnUp=findViewById(R.id.tvSignUp);


        rSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });

    }



    private void registerUser(){

        String email=remail.getText().toString().trim();
        String pswd=rpswd.getText().toString().trim();


        if(TextUtils.isEmpty(email)){
            //email is empty
            Toast.makeText(this, "Please enter email", Toast.LENGTH_SHORT).show();
            return;   // stop the function for further execution
        }

        if(TextUtils.isEmpty(pswd)){
            //password is empty
            Toast.makeText(this, "Please enter pswd", Toast.LENGTH_SHORT).show();
            return;
        }

        // if email pswd ok
        progressDialog.setMessage("Registering user      ...");
        progressDialog.show();

        mFirebaseAuth.createUserWithEmailAndPassword(email, pswd).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                progressDialog.dismiss();
                if(task.isSuccessful())
                    //what if he is logged in
                    Toast.makeText(testlogin.this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                else {
                    Toast.makeText(testlogin.this, "Failed to Register", Toast.LENGTH_SHORT).show();

                }
            }
        });


    }






    }

