package com.example.hariomloginregister;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class s_login extends AppCompatActivity {


    EditText remail,rpswd;
    Button rSignIn;
    TextView tvSingnUp;
    FirebaseAuth mFirebaseAuth;
    private FirebaseAuth.AuthStateListener mAuthStateListener;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        mFirebaseAuth = FirebaseAuth.getInstance();
        remail = findViewById(R.id.tfemail);
        rpswd = findViewById(R.id.tfpswd);
        rSignIn = findViewById(R.id.retBtn);
        tvSingnUp = findViewById(R.id.tvSignUp);

        mAuthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser mFirebaseUser = mFirebaseAuth.getCurrentUser();
                if (mFirebaseUser != null) {
                    Toast.makeText(s_login.this, "You are logged in ", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(s_login.this, s_home.class));
                } else {

                    Toast.makeText(s_login.this, "Please Login", Toast.LENGTH_SHORT).show();
                }
            }
        };

        rSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String vemail = remail.getText().toString();
                String vpswd = rpswd.getText().toString();

                if (vemail.isEmpty()) {
                    remail.setError("Please Enter Email");
                    remail.requestFocus();
                } else if (vpswd.isEmpty()) {
                    rpswd.setError("Please Enter Password");
                    rpswd.requestFocus();
                } else if (vemail.isEmpty() && vpswd.isEmpty()) {
                    remail.setError("Please Enter Email");
                    rpswd.setError("Please enter password");
                    Toast.makeText(s_login.this, "Please provide mandatory information", Toast.LENGTH_SHORT).show();
                } else if (!(vemail.isEmpty() && vpswd.isEmpty())) {  // mFirebaseAuth.signInWithEmailAndPassword(vemail,vpswd);  VS mFirebaseAuth.signInWithEmailAndPassword(vemail,vpswd);    <--  this is the main line to s_signUp a user.

                    mFirebaseAuth.signInWithEmailAndPassword(vemail, vpswd).addOnCompleteListener(s_login.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                //  startActivity(new Intent(s_login.this, s_hw_retrieve.class));

                                Intent myIntent = new Intent(s_login.this, s_hw_retrieve.class);
                                myIntent.putExtra("name", "FirstKeyValue");
                                myIntent.putExtra("class", "SecondKeyValue");
                                startActivity(myIntent);
                                Toast.makeText(s_login.this, "Login Successful", Toast.LENGTH_SHORT).show();

                            } else {
                                Toast.makeText(s_login.this, "Login Error , please s_login againn", Toast.LENGTH_SHORT).show();

                            }

                        }
                    });

                }

            }
        });


        tvSingnUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(s_login.this, s_signUp.class));
            }
        });


    }
    @Override
    protected void onStart() {
        super.onStart();
        mFirebaseAuth.addAuthStateListener(mAuthStateListener);

    }
}


