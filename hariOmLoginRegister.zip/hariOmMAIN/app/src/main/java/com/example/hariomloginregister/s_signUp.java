package com.example.hariomloginregister;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class s_signUp extends AppCompatActivity {

    EditText remail,rpswd, rUid;
    Button rSignUp;
    TextView tvSignIn;
    FirebaseAuth mFirebaseAuth;
    FirebaseAuth.AuthStateListener mAuthListner;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        mFirebaseAuth = FirebaseAuth.getInstance();
        rUid = findViewById(R.id.tfUid);
        remail = findViewById(R.id.tfemail);
        rpswd = findViewById(R.id.tfpswd);
        rSignUp = findViewById(R.id.retBtn);
        tvSignIn = findViewById(R.id.tvSignIn);

        mAuthListner = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {

                if (firebaseAuth.getCurrentUser() != null) {

                    //Intent user account

                }
            }
        };


        rSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String vemail = remail.getText().toString();
                String vpswd = rpswd.getText().toString();
                String vUid = rUid.getText().toString();


                if (vemail.isEmpty()) {
                    remail.setError("Please Enter Email");
                    remail.requestFocus();
                } else if (vpswd.isEmpty()) {
                    rpswd.setError("Please Enter Password");
                    rpswd.requestFocus();
                } else if (vemail.isEmpty() && vpswd.isEmpty()) {
                    remail.setError("Please Enter Email");
                    rpswd.setError("Please enter password");
                    Toast.makeText(s_signUp.this, "Please provide mandatory information", Toast.LENGTH_SHORT).show();
                } else if (!(vemail.isEmpty() && vpswd.isEmpty())) {

                    // mFirebaseAuth.createUserWithEmailAndPassword(vemail,vpswd);     <--  this is the main line to s_signUp a user.

                    mFirebaseAuth.createUserWithEmailAndPassword(vemail, vpswd).addOnCompleteListener(s_signUp.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(s_signUp.this, "New User Registered", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(s_signUp.this, s_login.class));

//                                            Intent intent=new Intent(s_signUp.this, s_home.class);
//                                            startActivity(intent);
                            } else if (!task.isSuccessful())
                                Toast.makeText(s_signUp.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                        }
                    });
                }


            }
        });

        tvSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(s_signUp.this, s_login.class));
            }
        });


    }

    @Override
    protected void onStart() {
        super.onStart();

        mFirebaseAuth.addAuthStateListener(mAuthListner);

    }
}
